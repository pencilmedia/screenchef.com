/*
 * CONFIDENTIAL COMPUTER CODE AND INFORMATION
 * COPYRIGHT (C) 2000-2013 VENDAVO, INC. ALL RIGHTS RESERVED.
 * REPRODUCTION BY ANY MEANS EXPRESSLY FORBIDDEN WITHOUT THE WRITTEN
 * PERMISSION OF THE OWNER.
 */
package com.BPE.adapter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.StringTokenizer;

import com.vendavo.adv.analysis.pricemart.api.meta.ColumnDefinition;
import com.vendavo.adv.analysis.pricemart.api.meta.FactColumnDefinition;
import com.vendavo.adv.analysis.pricemart.api.meta.FactDefinition;
import com.vendavo.adv.analysis.pricemart.api.meta.PricemartDefinition;
import com.vendavo.adv.analysis.pricemart.api.result.VPricemartResultSet;
import com.vendavo.adv.analysis.pricemartapi.internal.engine.Pricemart;
import com.vendavo.adv.analysis.pricemartapi.internal.engine.PricemartManager;
import com.vendavo.cl.Fmt;
import com.vendavo.cl.StringHelper;
import com.vendavo.cl.businesscalendar.SingleDayTimePeriod;
import com.vendavo.cl.log.VLog;
import com.vendavo.core.adapter.AdapterDefinition;
import com.vendavo.core.property.AdapterProps;
import com.vendavo.core.query.VResultRow;
import com.vendavo.core.util.FileHelper;
import com.vendavo.core.util.VenProperties;
import com.vendavo.platform.adapter.api.Adapter;
import com.vendavo.platform.query.QueryManager;
import com.vendavo.platform.query.VPagedResultSet;
import com.vendavo.platform.query.VPagedResultSetImpl;
import com.vendavo.platform.query.pricemart.PricemartQueryManager;
import com.vendavo.platform.vql.VQLException;
import com.vendavo.platform.vql.VQLFacility;
import com.vendavo.platform.vql.VSELECT;
import com.vendavo.util.api.VMoney;
import com.vendavo.util.api.VQuantity;
import com.vendavo.util.api.VUnitAmountSys;

/**
 * @author tganaj
 */
public class PricemartExporter
    extends Adapter
{
    private static final VLog LOG = VLog.getInstance(PricemartExporter.class.getName());

    private VSELECT m_pricemartQuery;

    protected String m_datePattern;
    private String m_pricemartName;
    private String m_propertyFile;
    private String m_query;
    protected int m_fileCount;
    protected String m_columnMappingFile;
    protected String m_columnListOnly;
    private PricemartQueryManager _pqm;
    private LinkedHashMap<String,String> m_columnMappingMap;
   
    /**
     * Initializes all the members using proper adapter properties.
     *
     * @param adapterDef
     * @throws IllegalArgumentException
     */
    protected void initMembers(AdapterDefinition adapterDef)
        throws IllegalArgumentException
    {
		m_datePattern = AdapterProps.PROPERTY_ADAPTER_DATE_PATTERN
				.getString(getAdapterDefinition());
		String fileCountS = (String) adapterDef.getProperties().get(
				"adapter.file.count");
		m_columnListOnly = (String) adapterDef.getProperties().get(
				"adapter.column.list.only");
		m_propertyFile = (String) adapterDef.getProperties().get(
				"adapter.pricemart.property.file");
		Properties prop = new Properties();
		try {
			if (m_propertyFile!=null)
			{
				prop.load(new FileInputStream(m_propertyFile));
			}
		} catch (IOException e) {
			throw new VQLException(VQLFacility.VQL_MSG.text("Property file \""+m_propertyFile+"\" is not valid property file."));
		}
		if (prop.get(AdapterProps.PROPERTY_ADAPTER_DATE_PATTERN.getName())!=null) m_datePattern = (String) prop.get(AdapterProps.PROPERTY_ADAPTER_DATE_PATTERN.getName());
		if (m_datePattern!=null)
		{
			m_datePattern=m_datePattern.trim();
			if (m_datePattern.startsWith("\"") && m_datePattern.endsWith("\"") && m_datePattern.length()>1) m_datePattern=m_datePattern.substring(1,m_datePattern.length()-1);
			else if (m_datePattern.startsWith("'") && m_datePattern.endsWith("'") && m_datePattern.length()>1) m_datePattern=m_datePattern.substring(1,m_datePattern.length()-1);
		}
		if (prop.get("adapter.file.count")!=null) fileCountS = (String) prop.get("adapter.file.count");		
		try{
			if ((fileCountS != null) && (fileCountS.length() != 0)) {
				m_fileCount = Integer.parseInt(fileCountS);
			}
			else 
				m_fileCount=1;
			if ("true".equalsIgnoreCase(m_columnListOnly)) m_fileCount=1;
		}
		catch (NumberFormatException nfe)
		{
			throw new VQLException(VQLFacility.VQL_MSG.text("Property \"adapter.file.count\" must contain integer value >0."));			
		}
		if (!"true".equalsIgnoreCase(m_columnListOnly) && (fileCountS==null || fileCountS.trim().equals("") || m_fileCount<1)) 
			throw new VQLException(VQLFacility.VQL_MSG.text("Property \"adapter.file.count\" must contain integer value >0."));

		m_columnMappingFile = (String) adapterDef.getProperties().get(
				"adapter.column.mapping.file");
		if (prop.get("adapter.column.mapping.file")!=null) m_columnMappingFile = (String) prop.get("adapter.column.mapping.file");				
		if (!"true".equalsIgnoreCase(m_columnListOnly) && (m_columnMappingFile==null || m_columnMappingFile.trim().equals("")))
		{
			throw new VQLException(VQLFacility.VQL_MSG.text("Property \"adapter.column.mapping.file\" must be provided."));						
		}
    	m_query = AdapterProps.PROPERTY_ADAPTER_PRICEMART_PRICEMART_QUERY.getString(getAdapterDefinition());
		if (prop.get(AdapterProps.PROPERTY_ADAPTER_PRICEMART_PRICEMART_QUERY.getName())!=null) m_query = (String) prop.get(AdapterProps.PROPERTY_ADAPTER_PRICEMART_PRICEMART_QUERY.getName());				
		if (m_query==null)
		{
			throw new VQLException(VQLFacility.VQL_MSG.text("Property \"adapter.pricemart.pricemart-query\" must be provided."));						
		}

		int fromIndex  =m_query.toLowerCase().indexOf(" from ");
    	if (fromIndex != -1)
        {
        	m_pricemartName= m_query.substring(fromIndex+6);
        }
    	else 
    	{
        	m_pricemartName=m_query;        	
    	}

    }

    /**
     * Initializes, transforms and creates XML file based on the adapter
     * definition.
     *
     * @param adapterDef
     * @return String - Success in case of successful operation.
     */
    public String invoke(AdapterDefinition adapterDef)
    {
        initMembers(adapterDef);
    	String fileName = adapterDef.getFileName();
    	String dir = FileHelper.getDirectoryProperty(AdapterProps.PROPERTY_EXPORT_DIR);
        if (!"true".equalsIgnoreCase(m_columnListOnly)) {
        	prepareColumnMapping();        
        	QueryManager qm = getQuery().prepare();

        	if (qm instanceof PricemartQueryManager)
        	{
        		_pqm = (PricemartQueryManager) qm;
            
            	return dumpResultSet(_pqm, dir, fileName);
        	}
        }
        else {
        	dumpColumnList(_pqm, dir, fileName);
        }
        return "";
    }
    
    private void prepareColumnMapping()
    {
    	m_columnMappingMap = new LinkedHashMap<String,String>();
    	try {
    		BufferedReader br = new BufferedReader(new FileReader(m_columnMappingFile));
    		String line;
    		StringTokenizer st;
    		String delim = AdapterProps.PROPERTY_ADAPTER_DELIMITER.getString(getAdapterProperties());
    		int lineNr=0;
    		int writtenRows=0;
    		while ((line = br.readLine()) != null) {
    			lineNr++;
    			if (!line.trim().equals("")) {
    				st = new StringTokenizer(line, delim);
    				String key=null, value=null;
    				if (st.hasMoreTokens())
    					key = st.nextToken();
    				else {
    					throw new VQLException(VQLFacility.VQL_MSG.text("Line "+lineNr+" in mapping file is empty"));
    				}
    				if (st.hasMoreTokens())
    					value = st.nextToken();
    				else 
    					throw new VQLException(VQLFacility.VQL_MSG.text("Mapping columns are not provided properly (at line "+lineNr+") : '"+line+"'"));
    				if (!key.startsWith("#")) {
    					m_columnMappingMap.put(key, value);
    					writtenRows++;
    				}
    			}
    		} 
    		if (writtenRows==0) throw new VQLException(VQLFacility.VQL_MSG.text("Mapping file "+m_columnMappingFile+" is empty!"));

    	} 
    	catch (IOException e) {    	    	 
    		throw new VQLException(VQLFacility.VQL_MSG.text("Invalid mapping file is specified by the user:\n"+e.getMessage()));
    	}
    	catch (VQLException e) {    	    	 
    		throw e;
    	}
    }
    
	private String dumpColumnList(PricemartQueryManager pqm, String dir, String fileName)
    {
		Pricemart pm = PricemartManager.getInstance().getPricemart(m_pricemartName);
		PricemartDefinition pmd = pm.getPricemartDefinition();
		Map m = pmd.getAllFactTableDefinitions();
		Iterator<Entry> i = m.entrySet().iterator();
		String defaultStage=null;
		while (i.hasNext() && defaultStage==null)
		{
			FactDefinition fd = (FactDefinition) (i.next()).getValue();
			if (fd.isDefault()) defaultStage=fd.getName();
		}
		List<ColumnDefinition> allColumnDefinitions = pmd.getAllColumnDefinitions();
		Iterator<ColumnDefinition> it = allColumnDefinitions.iterator();
    	StringBuffer sb = new StringBuffer();
        int rowExported=0;
    	Map<?,?> properties = getAdapterProperties();
    	if (!fileName.endsWith("/") && !fileName.endsWith("\\")) fileName=fileName+"/";
    	fileName = fileName+this.m_adapterDef.getName();
        String path = FileHelper.makePath(dir, fileName);
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
		String date = sdf2.format(new Date());

		try {
			PrintWriter writers = new PrintWriter(new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(path+"_File0_"+date+".csv"),
							getDefaultEncoding())));
			String delim = AdapterProps.PROPERTY_ADAPTER_DELIMITER.getString(properties);

			if ("true".equalsIgnoreCase(m_columnListOnly)) writers.write("#PricemartColumn"+delim+"PriceDataColumn\n");

			while (it.hasNext())
			{
				ColumnDefinition cd = it.next();
				FactColumnDefinition fcd = cd.getColumnSourceDefinition(defaultStage);
				if (!cd.isTempLoadingColumn() && fcd!=null)
				{
					writers.write(cd.getName()+delim);
					if (it.hasNext()) writers.write("\n");
					rowExported++;
				}        			
			}
			writers.close();
			String msg = Fmt.s("Exported {0} rows.", rowExported);
			this.getAdapterHistory().setResultMessage(msg);
			this.getAdapterHistory().setRowsExported(rowExported);
			this.getAdapterHistory().save();
			return msg;
		}
		catch (IllegalArgumentException e) {
			throw new VQLException(VQLFacility.VQL_MSG.text("Invalid date format in the adapter: '"+m_datePattern+"'"));
		}
		catch (IOException e) {
			LOG.error("Count not open file \"{0}\" for writing CSV content", path);
		}
		return "";
    }
    
    private String dumpResultSet(PricemartQueryManager pqm, String dir, String fileName)
    {
    	VPagedResultSet pages = new VPagedResultSetImpl(pqm, 1000);
    	VPricemartResultSet page0 = (VPricemartResultSet) pages.getPage(0);    	

        Collection<String> allFields = page0.getResultColumnNames();
    	Iterator<String> it = allFields.iterator();
    	Map<?,?> properties = getAdapterProperties();
    	String delim = AdapterProps.PROPERTY_ADAPTER_DELIMITER.getString(properties);

    	int pricingCurrencyColumnIndex=-1;
        if (fileName.trim().toLowerCase().endsWith(".csv")) fileName = fileName.trim().substring(0,fileName.length()-4);
    	if (!fileName.endsWith("/") && !fileName.endsWith("\\")) fileName=fileName+"/";
    	String fileNameBase=fileName;
    	fileName = fileName+this.m_adapterDef.getName();
        String path = FileHelper.makePath(dir, fileName);

        File file = new File(path);
        FileHelper.makeDirectory(file.getParent());

        PrintWriter[] writers = new PrintWriter[m_fileCount];
        int rowExported=0;
    	try {
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
			String date = sdf2.format(new Date());
			if (m_fileCount > 1) {
				for (int i = 0; i < m_fileCount; i++) {
					writers[i] = new PrintWriter(new BufferedWriter(
							new OutputStreamWriter(new FileOutputStream(path+"_File"+i+"_"+date+".csv"),
									getDefaultEncoding())));
				}
			} else {
				writers[0] = new PrintWriter(new BufferedWriter(
						new OutputStreamWriter(new FileOutputStream(path+"_File0_"+date+".csv"),
								getDefaultEncoding())));
			}
			int ind=0;
			Object[] arr=null;
			if (!"true".equalsIgnoreCase(m_columnListOnly)) arr =  m_columnMappingMap.entrySet().toArray();
    		while (it.hasNext())
    		{
    			String s = it.next();
    			Entry<String, String> e = (Entry<String, String>) arr[ind];
				for (int i = 0; i < m_fileCount; i++) {
					if (ind==0) writers[i].write("#");
					if (e.getKey().toUpperCase().trim().equals("VPRICINGCURRENCY")) pricingCurrencyColumnIndex=ind;
					writers[i].write(e.getValue());
					if (it.hasNext()) writers[i].write(delim);
				}
				ind++;
    		}

    		for (int i = 0; i < m_fileCount; i++) {
    			writers[i].write("\n");
    		}

    		String formValue;
    		SimpleDateFormat sdf = new SimpleDateFormat(m_datePattern);
    		int fileIndex=0;
    		int pageCount = pages.getPageCount();
    		int pageSize = pages.getPageSize();
    		for (int i = 0; i < pageCount; i++)
    		{
    			VPricemartResultSet page = (VPricemartResultSet) pages.getPage(i);
    			List<? extends VResultRow> rows = page.getRows();
    			Iterator<? extends VResultRow> rowIt = rows.iterator();
    			while (rowIt.hasNext())
    			{              
    				VResultRow row = (VResultRow) rowIt.next();
    				int count = row.getColumnCount();
    				for (int index=0; index<count; index++)
    				{
    					if (index>0) writers[fileIndex].write(delim);
    					Object fieldValue = row.getValue(index);
    					if (fieldValue instanceof SingleDayTimePeriod)
    					{
    						SingleDayTimePeriod sdtp = (SingleDayTimePeriod) fieldValue;
    						formValue = sdf.format(sdtp.getStartDate());
    					}
    					else if (fieldValue instanceof VMoney)
    					{
    						VMoney val = (VMoney) fieldValue;
    						formValue = (val.getMoneyValue() != null) ? val.getMoneyValue()
    								.toString() : null;
    					}
    					else if (fieldValue instanceof VQuantity)
    					{
    						VQuantity val = (VQuantity) fieldValue;
    						formValue = (val.getQuantityValue() != null) ? val.getQuantityValue()
    								.toString() : null;
    					}
    					else if (fieldValue instanceof VUnitAmountSys)
    					{
    						VUnitAmountSys val = (VUnitAmountSys) fieldValue;
    						formValue = (val.getMoneyValue() != null) ? val.getMoneyValue()
    								.toString() : null;
    					}
    					else if (index==pricingCurrencyColumnIndex)
    					{								
    						formValue = page0.getCurrency().getVISOCode();
    					}
    					else {
    						formValue = (fieldValue != null) ? fieldValue
    								.toString() : null;
    					}
    					String encodedValue = StringHelper.csvEncode(formValue);
    					if (encodedValue.indexOf(delim)==-1) encodedValue=encodedValue.replaceAll("\"", "\"\"");
    					if (encodedValue.indexOf("\"")>0) encodedValue="\""+encodedValue+"\"";
    					else if (encodedValue.indexOf("#")!=-1 && !encodedValue.startsWith("\"")) encodedValue="\""+encodedValue+"\"";
    					if (encodedValue!=null) writers[fileIndex].write(encodedValue);
    				}
    				rowExported++;
    				writers[fileIndex].write("\n");
    				fileIndex=(fileIndex+1)%m_fileCount;
    			}
    			if (page.getRowCount() < pageSize)
    			{
    				break;
    			}
    		}
    		ArrayList<File> al = new ArrayList<File>();
			for (int i = 0; i < m_fileCount; i++) {
				writers[i].close();
				al.add(new File(path+"_File"+i+"_"+date+".csv"));
			}
	        path = FileHelper.makePath(dir, fileNameBase);
			if (!"true".equalsIgnoreCase(m_columnListOnly)) {
				com.vendavo.cl.io.FileHelper.createZipFile(path+"/"+VenProperties.getWorldName()+"PriceMartExtract"+date+".zip", al);
				for (File f : al) f.delete();
			}
			String msg = Fmt.s("Exported {0} rows.", rowExported);
			this.getAdapterHistory().setResultMessage(msg);
			this.getAdapterHistory().setRowsExported(rowExported);
			this.getAdapterHistory().save();
			return msg;
    	}
    	catch (IllegalArgumentException e) {
    		throw new VQLException(VQLFacility.VQL_MSG.text("Invalid date format in the adapter: '"+m_datePattern+"'"));
    	}
    	catch (IOException e) {
    		LOG.error("Count not open file \"{0}\" for writing CSV content", path);
    	}
    	return  "";
    }
    
    /**
     * Get the query string defined by the property
     * "adapter.pricemart.pricemart-query" and parses the query.
     *
     * @return VSELECT
     */
    public VSELECT getQuery()
    {
        if (m_pricemartQuery == null) {

        	StringBuffer sb = new StringBuffer();
        	Iterator<String> i = m_columnMappingMap.keySet().iterator();
        	while (i.hasNext())
        	{
        		sb.append(i.next());
        		if (i.hasNext()) sb.append(",");
        	}
        	
    		int fromIndex  =m_query.toLowerCase().indexOf(" from ");
        	if (fromIndex != -1)
            {
        		m_query = "select "+sb.toString()+" from "+m_query.substring(fromIndex+6);
            }
        	else 
        	{
        		m_query = "select "+sb.toString()+" from "+m_query;
        	}
            m_pricemartQuery = VSELECT.newQuery(m_query, null);
        }
        return m_pricemartQuery;
    }
}
