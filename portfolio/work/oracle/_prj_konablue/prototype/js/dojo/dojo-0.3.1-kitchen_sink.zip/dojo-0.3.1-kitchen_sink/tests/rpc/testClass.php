<?
class testClass {

	function myecho ($somestring) {
		return "<P>" . $somestring . "<P>";
	}

	function contentB () {
		return "<P>Content B</p>";
	}

	function contentC () {
		return "<P>Content C</p>";
	}

	function add($x,$y) {
		return $x + $y;
	}
}
?>
